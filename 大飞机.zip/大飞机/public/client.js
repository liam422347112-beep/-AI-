const canvas = document.querySelector("#gameCanvas");
const ctx = canvas.getContext("2d");

const joinPanel = document.querySelector("#joinPanel");
const nameInput = document.querySelector("#nameInput");
const slotSelect = document.querySelector("#slotSelect");
const joinBtn = document.querySelector("#joinBtn");
const connectionText = document.querySelector("#connectionText");
const readyBtn = document.querySelector("#readyBtn");
const startWaveBtn = document.querySelector("#startWaveBtn");
const speedBtn = document.querySelector("#speedBtn");
const resetBtn = document.querySelector("#resetBtn");
const phaseText = document.querySelector("#phaseText");
const waveText = document.querySelector("#waveText");
const nextWaveText = document.querySelector("#nextWaveText");
const enemyText = document.querySelector("#enemyText");
const playersPanel = document.querySelector("#playersPanel");
const towerButtons = document.querySelector("#towerButtons");
const buildHint = document.querySelector("#buildHint");
const selectionPanel = document.querySelector("#selectionPanel");
const upgradeBtn = document.querySelector("#upgradeBtn");
const sellBtn = document.querySelector("#sellBtn");
const logList = document.querySelector("#logList");

let ws;
let clientId = null;
let state = null;
let config = null;
let mySlot = null;
let selectedTowerType = "arrow";
let selectedTowerId = null;
let mouse = null;
let towerTab = "basic";
let expandedCategory = null;

connect();
resizeCanvas();
requestAnimationFrame(drawLoop);

function resizeCanvas() {
  if (!config) return;
  const rect = canvas.getBoundingClientRect();
  const dpr = window.devicePixelRatio || 1;
  canvas.width = Math.max(1, Math.floor(rect.width * dpr));
  canvas.height = Math.max(1, Math.floor(rect.height * dpr));
}
window.addEventListener("resize", () => { resizeCanvas(); });

function mapWidth() {
  return canvas.width;
}

function mapHeight() {
  return canvas.height;
}

function gridToMapX(x) {
  return (x / config.cols) * mapWidth();
}

function gridToMapY(y) {
  return (y / config.rows) * mapHeight();
}

function mapToGridX(x) {
  return Math.floor((x / mapWidth()) * config.cols);
}

function mapToGridY(y) {
  return Math.floor((y / mapHeight()) * config.rows);
}

function worldPoint(item) {
  return {
    x: gridToMapX(item.x / config.gridSize),
    y: gridToMapY(item.y / config.gridSize),
  };
}

function worldRadius(radius) {
  return radius * ((mapWidth() / (config.cols * config.gridSize) + mapHeight() / (config.rows * config.gridSize)) / 2);
}


function connect() {
  const protocol = location.protocol === "https:" ? "wss" : "ws";
  ws = new WebSocket(`${protocol}://${location.host}`);
  ws.addEventListener("open", () => {
    connectionText.textContent = "已连接，输入昵称并选择位置。";
  });
  ws.addEventListener("message", (event) => {
    const message = JSON.parse(event.data);
    if (message.type === "hello") {
      clientId = message.clientId;
      config = message;
      resizeCanvas();
      renderTowerButtons();
    }
    if (message.type === "state") {
      state = message;
      mySlot = findMySlot();
      updateUi();
    }
    if (message.type === "error") {
      connectionText.textContent = message.message;
    }
  });
  ws.addEventListener("close", () => {
    connectionText.textContent = "连接已断开，请刷新页面重连。";
  });
}

function send(type, payload = {}) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type, ...payload }));
}

function findMySlot() {
  if (!state?.players) return null;
  const entry = Object.entries(state.players).find(([, player]) => player.clientId === clientId);
  return entry ? Number(entry[0]) : null;
}

function updateUi() {
  if (!state || !config) return;
  const myPlayer = mySlot ? state.players[mySlot] : null;
  const canJoin = state.phase === "lobby";
  joinPanel.classList.toggle("hidden", Boolean(myPlayer));
  joinBtn.disabled = !canJoin;
  slotSelect.disabled = !canJoin;
  nameInput.disabled = !canJoin;
  if (!myPlayer && !canJoin) connectionText.textContent = "游戏已经开始，你现在是观战模式。";
  phaseText.textContent = state.phase === "lobby" ? "大厅" : state.phase === "playing" ? "战斗中" : "已结束";
  waveText.textContent = `${state.wave} / ${config.totalWaves}`;
  const armorName = { physical: "物理", magic: "魔法", resistance: "抗性", holy: "神圣" };
  const dmgName = { physical: "物理", magic: "魔法", pierce: "穿刺", chaos: "混乱" };
  const counterMap = { physical: "magic", magic: "physical", pierce: "resistance", chaos: "holy" };
  nextWaveText.textContent = state.nextWaveConfig ? `${state.nextWaveConfig.name} x ${state.nextWaveConfig.count} [${armorName[state.nextWaveConfig.armorType] || ""}护甲]` : "已完成";
  enemyText.textContent = state.enemies.length + (state.spawning && state.waveConfig ? ` + ${state.waveConfig.count - state.spawnCount}` : "");
  readyBtn.disabled = !myPlayer || state.phase !== "lobby";
  readyBtn.textContent = myPlayer?.ready ? "取消准备" : "准备";
  const isHost = mySlot === state.hostSlot;
  startWaveBtn.disabled = !isHost || state.phase === "ended" || state.spawning || state.enemies.length > 0 || state.wave >= config.totalWaves || (state.phase === "lobby" && !allReady());
  speedBtn.disabled = !isHost;
  speedBtn.textContent = `${state.speed}x 速度`;
  const canReset = isHost || state.phase === "ended";
  resetBtn.disabled = !canReset;
  renderPlayers();
  renderLogs();
  updateSelectionPanel();
}

function allReady() {
  const players = Object.values(state.players).filter((player) => player.connected);
  return players.length > 0 && players.every((player) => player.ready);
}

function renderPlayers() {
  playersPanel.innerHTML = "";
  const tc = state.towerCounts || {};
  const playerCount = Object.values(state.players).filter(p => p.connected).length;
  const leakLimit = playerCount * 50;
  const totalEnemies = state.enemies.length;
  if (leakLimit > 0 && totalEnemies > leakLimit * 0.8) {
    buildHint.style.color = totalEnemies >= leakLimit ? "#ff4444" : "#ffaa44";
    buildHint.textContent = `⚠ 场上怪物 ${totalEnemies}/${leakLimit}（漏怪上限）`;
  }
  for (let slot = 1; slot <= 8; slot += 1) {
    const player = state.players[slot];
    const role = config.playerRoles[slot];
    const towerCount = tc[slot] || 0;
    const div = document.createElement("div");
    div.className = `player-card${slot === mySlot ? " mine" : ""}`;
    div.style.borderColor = role.color;
    div.innerHTML = player
      ? `<strong>${slot}号 ${player.name}${slot === state.hostSlot ? "（房主）" : ""}</strong><span>${role.name} · ${player.connected ? "在线" : "离线"} · ${player.ready ? "已准备" : "未准备"}</span><span>生命 ${player.lives} · 金币 ${player.gold} · 塔 ${towerCount}</span>`
      : `<strong>${slot}号 ${role.name}${slot === state.hostSlot ? "（房主）" : ""}</strong><span>空位</span>`;
    playersPanel.append(div);
  }
}

function renderLogs() {
  logList.innerHTML = "";
  const logs = state.logs || [];
  if (!logs.length) {
    const empty = document.createElement("p");
    empty.textContent = "暂无战斗日志。";
    logList.append(empty);
    return;
  }
  logs.forEach((log) => {
    const item = document.createElement("p");
    const time = new Date(log.time).toLocaleTimeString("zh-CN", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
    item.textContent = `[${time}] ${log.message}`;
    logList.append(item);
  });
}

function renderTowerButtons() {
  if (!config) return;
  const dtName = { physical: "物", magic: "魔", pierce: "穿", chaos: "混" };
  const categories = { basic: [], debuff: [], aura: [], growth: [] };
  const hotkeys = { arrow: "Q", frost: "W", cannon: "E", poison: "R", armorbreak: "Y", corrosion: "U", aura_speed: "T", aura_damage: "G", growth_kill: "I", growth_gold: "K" };
  const categoryLabels = { basic: "基础", debuff: "减防", aura: "光环", growth: "成长" };
  Object.entries(config.towerTypes).forEach(([key, tower]) => {
    const cat = tower.category || "basic";
    categories[cat].push({ key, hotkey: hotkeys[key] || "" });
  });

  towerButtons.innerHTML = "";
  const tabBar = document.createElement("div");
  tabBar.className = "tower-tab-bar";
  ["basic", "special"].forEach((tab) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `tower-tab${towerTab === tab ? " active" : ""}`;
    btn.textContent = tab === "basic" ? "基础塔" : "特殊塔";
    btn.addEventListener("click", () => { towerTab = tab; expandedCategory = null; renderTowerButtons(); });
    tabBar.append(btn);
  });
  towerButtons.append(tabBar);

  if (towerTab === "basic") {
    const grid = document.createElement("div");
    grid.className = "command-grid";
    categories.basic.forEach((cmd) => renderTowerButton(grid, cmd, dtName));
    towerButtons.append(grid);
  } else {
    const grid = document.createElement("div");
    grid.className = "command-grid";
    categories.debuff.forEach((cmd) => renderTowerButton(grid, cmd, dtName));
    towerButtons.append(grid);
    renderCategorySection("aura", categoryLabels.aura, categories.aura, dtName);
    renderCategorySection("growth", categoryLabels.growth, categories.growth, dtName);
  }
}

function renderTowerButton(container, cmd, dtName) {
  const tower = config.towerTypes[cmd.key];
  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = `command-button${selectedTowerType === cmd.key ? " selected" : ""}`;
  const dtLabel = dtName[tower.damageType] || "";
  btn.innerHTML = `<strong>${cmd.hotkey}</strong><span>${tower.name}</span><small>${tower.cost}金 [${dtLabel}]</small>`;
  btn.addEventListener("click", () => { selectedTowerType = cmd.key; selectedTowerId = null; renderTowerButtons(); updateSelectionPanel(); });
  container.append(btn);
}

function renderCategorySection(catKey, label, items, dtName) {
  const section = document.createElement("div");
  section.className = "tower-category";
  const header = document.createElement("button");
  header.type = "button";
  header.className = `category-header${expandedCategory === catKey ? " expanded" : ""}`;
  header.innerHTML = `<span>${label}塔</span><small>${items.length}种</small><span class="arrow">${expandedCategory === catKey ? "▼" : "▶"}</span>`;
  header.addEventListener("click", () => {
    expandedCategory = expandedCategory === catKey ? null : catKey;
    renderTowerButtons();
  });
  section.append(header);
  if (expandedCategory === catKey) {
    const grid = document.createElement("div");
    grid.className = "command-grid category-content";
    items.forEach((cmd) => renderTowerButton(grid, cmd, dtName));
    section.append(grid);
  }
  towerButtons.append(section);
}

function updateSelectionPanel() {
  if (!state || !config) return;
  const armorName = { physical: "物理", magic: "魔法", resistance: "抗性", holy: "神圣" };
  const dmgName = { physical: "物理", magic: "魔法", pierce: "穿刺", chaos: "混乱" };
  const counterMap = { physical: "magic", magic: "physical", pierce: "resistance", chaos: "holy" };
  const nextArmor = state.nextWaveConfig?.armorType;
  const tower = state.towers.find((item) => item.id === selectedTowerId);
  if (tower && tower.ownerSlot === mySlot) {
    const type = config.towerTypes[tower.typeKey];
    const cost = getUpgradeCost(tower);
    const dtLabel = dmgName[type.damageType] || "";
    const counter = nextArmor ? (counterMap[type.damageType] === nextArmor ? " ✓克制" : counterMap[nextArmor] === type.damageType ? " ✗被克" : "") : "";
    selectionPanel.innerHTML = `<strong>${type.name} Lv.${tower.level}</strong> [${dtLabel}]${counter}<br>伤害 ${Math.round(tower.damage)} · 射程 ${Math.round(tower.range)}<br>${tower.level >= 5 ? "已满级" : `升级费用 ${cost} 金`}`;
    upgradeBtn.disabled = tower.level >= 5 || state.players[mySlot].gold < cost;
    sellBtn.disabled = false;
    buildHint.textContent = "已选择自己的塔，可升级或出售。";
    return;
  }
  const selected = config.towerTypes[selectedTowerType];
  const dtLabel = dmgName[selected.damageType] || "";
  const counter = nextArmor ? (counterMap[selected.damageType] === nextArmor ? " ✓克制下一波" : counterMap[nextArmor] === selected.damageType ? " ✗被下一波克制" : "") : "";
  selectionPanel.innerHTML = `<strong>${selected.name}</strong> [${dtLabel}]${counter}<br>造价 ${selected.cost} 金<br>${selected.desc}`;
  upgradeBtn.disabled = true;
  sellBtn.disabled = true;
  buildHint.textContent = mySlot ? `你是 ${mySlot} 号，只能在自己的象限建塔。` : "先加入一个玩家位置。";
}

function canvasPoint(event) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: ((event.clientX - rect.left) / rect.width) * mapWidth(),
    y: ((event.clientY - rect.top) / rect.height) * mapHeight(),
  };
}

function handleCanvasClick(event) {
  if (!state || !config || !mySlot) return;
  const point = canvasPoint(event);
  const tower = state.towers.find((item) => distance(point, worldPoint(item)) <= 8);
  if (tower) {
    selectedTowerId = tower.id;
    updateSelectionPanel();
    return;
  }
  const gridX = mapToGridX(point.x);
  const gridY = mapToGridY(point.y);
  send("build", { gridX, gridY, towerType: selectedTowerType });
}

function drawLoop() {
  draw();
  requestAnimationFrame(drawLoop);
}

function draw() {
  if (!config) return;
  resizeCanvas();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawMap();
  if (state) {
    drawTowers();
    drawEnemies();
    drawProjectiles();
    drawEffects();
    drawBuildPreview();
    drawSelection();
    drawPhaseOverlay();
  }
}

function drawMap() {
  const cellW = mapWidth() / config.cols;
  const cellH = mapHeight() / config.rows;
  ctx.fillStyle = "#102612";
  ctx.fillRect(0, 0, mapWidth(), mapHeight());

  const connectedCells = new Set(Object.values(config.pathRoutes || {}).flat().map(([x, y]) => `${x},${y}`));

  const virtualRoutes = [
    [...hCells(2, 27, 2), ...vCells(3, 17, 27), ...hCells(26, 2, 17), ...vCells(16, 3, 2), [3, 2]],
    [...hCells(6, 23, 5), ...vCells(6, 14, 23), ...hCells(22, 6, 14), ...vCells(13, 6, 6)],
  ];
  virtualRoutes.forEach((route) => route.forEach(([x, y]) => connectedCells.add(`${x},${y}`)));

  for (let y = 0; y < config.rows; y += 1) {
    for (let x = 0; x < config.cols; x += 1) {
      const buildSlot = getBuildSlotAt(x, y);
      const role = buildSlot ? config.playerRoles[buildSlot] : null;
      const path = connectedCells.has(`${x},${y}`);
      ctx.fillStyle = path ? "#3f6530" : (x + y) % 2 === 0 ? "#173819" : "#123015";
      ctx.fillRect(gridToMapX(x), gridToMapY(y), cellW, cellH);
      if (role && !path) {
        ctx.fillStyle = `${role.color}24`;
        ctx.fillRect(gridToMapX(x), gridToMapY(y), cellW, cellH);
      }
      ctx.strokeStyle = buildSlot === mySlot ? "rgba(255,240,168,.16)" : "rgba(255,255,255,.035)";
      ctx.strokeRect(gridToMapX(x), gridToMapY(y), cellW, cellH);
    }
  }

  Object.entries(config.buildAreas).forEach(([slot, areas]) => {
    const role = config.playerRoles[slot];
    areas.forEach((area) => {
      const x = gridToMapX(area.minX);
      const y = gridToMapY(area.minY);
      const w = (area.maxX - area.minX + 1) * cellW;
      const h = (area.maxY - area.minY + 1) * cellH;
      ctx.strokeStyle = role.color;
      ctx.lineWidth = Number(slot) === mySlot ? 3 : 1.5;
      ctx.strokeRect(x + 2, y + 2, w - 4, h - 4);
    });
  });

  Object.values(config.pathRoutes || { main: config.mainPathCells }).forEach((route) => {
    ctx.strokeStyle = "#d6f08b";
    ctx.lineWidth = Math.max(5, Math.min(cellW, cellH) * 0.18);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    route.forEach(([x, y], index) => {
      const px = gridToMapX(x + 0.5);
      const py = gridToMapY(y + 0.5);
      if (index === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.stroke();
  });

  Object.values(config.pathRoutes || { main: config.mainPathCells }).forEach((route) => {
    const start = route[0];
    drawMapMarker(gridToMapX(start[0] + 0.5), gridToMapY(start[1] + 0.5), "出怪", "#fff0a8");
  });
  drawMapMarker(mapWidth() / 2, mapHeight() / 2, "中心", "#ff9b6a");
}

function hCells(x1, x2, y) {
  const step = x1 <= x2 ? 1 : -1;
  const cells = [];
  for (let x = x1; x !== x2 + step; x += step) cells.push([x, y]);
  return cells;
}

function vCells(y1, y2, x) {
  const step = y1 <= y2 ? 1 : -1;
  const cells = [];
  for (let y = y1; y !== y2 + step; y += step) cells.push([x, y]);
  return cells;
}

function drawMapMarker(x, y, label, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.font = "bold 14px sans-serif";
  ctx.fillText(label, x + 10, y - 10);
}

function drawTowers() {
  state.towers.forEach((tower) => {
    const type = config.towerTypes[tower.typeKey];
    const point = worldPoint(tower);
    ctx.fillStyle = type.color;
    ctx.beginPath();
    ctx.arc(point.x, point.y, 6.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#10220f";
    ctx.font = "bold 8px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(tower.level, point.x, point.y + 3);
    ctx.textAlign = "left";
  });
}

function drawEnemies() {
  const cellSize = Math.min(mapWidth() / config.cols, mapHeight() / config.rows);
  state.enemies.forEach((enemy) => {
    const point = worldPoint(enemy);
    const radius = enemy.name === "Boss" ? cellSize * 0.42 : cellSize * 0.33;
    ctx.fillStyle = enemy.slowTimer > 0 ? "#8fdcff" : enemy.color;
    ctx.beginPath();
    ctx.arc(point.x, point.y, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(0,0,0,.65)";
    ctx.fillRect(point.x - cellSize * 0.38, point.y - radius - 7, cellSize * 0.76, 4);
    ctx.fillStyle = "#73ff66";
    ctx.fillRect(point.x - cellSize * 0.38, point.y - radius - 7, cellSize * 0.76 * Math.max(0, enemy.hp / enemy.maxHp), 4);
  });
}

function drawProjectiles() {
  state.projectiles.forEach((projectile) => {
    const point = worldPoint(projectile);
    ctx.fillStyle = projectile.color;
    ctx.beginPath();
    ctx.arc(point.x, point.y, 2.5, 0, Math.PI * 2);
    ctx.fill();
  });
}

function drawEffects() {
  state.effects.forEach((effect) => {
    const point = worldPoint(effect);
    ctx.strokeStyle = effect.color;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(point.x, point.y, worldRadius(effect.radius) * Math.max(0.2, effect.life * 4), 0, Math.PI * 2);
    ctx.stroke();
  });
}

function drawBuildPreview() {
  if (!mouse || !mySlot || selectedTowerId) return;
  const cellW = mapWidth() / config.cols;
  const cellH = mapHeight() / config.rows;
  const gridX = mapToGridX(mouse.x);
  const gridY = mapToGridY(mouse.y);
  const ownArea = getBuildSlotAt(gridX, gridY) === mySlot;
  const blocked = isPathCell(gridX, gridY) || state.towers.some((tower) => tower.gridX === gridX && tower.gridY === gridY);
  const type = config.towerTypes[selectedTowerType];
  const x = gridToMapX(gridX + 0.5);
  const y = gridToMapY(gridY + 0.5);
  const canBuild = ownArea && !blocked;
  ctx.fillStyle = canBuild ? "rgba(143,255,112,.2)" : "rgba(255,78,78,.22)";
  ctx.fillRect(gridToMapX(gridX) + 1, gridToMapY(gridY) + 1, cellW - 2, cellH - 2);
  ctx.strokeStyle = canBuild ? "rgba(210,255,169,.8)" : "rgba(255,102,102,.85)";
  ctx.strokeRect(gridToMapX(gridX) + 2, gridToMapY(gridY) + 2, cellW - 4, cellH - 4);
  ctx.beginPath();
  ctx.arc(x, y, worldRadius(type.range), 0, Math.PI * 2);
  ctx.stroke();
}

function drawSelection() {
  const tower = state.towers.find((item) => item.id === selectedTowerId);
  if (!tower) return;
  const point = worldPoint(tower);
  ctx.strokeStyle = tower.ownerSlot === mySlot ? "#fff0a8" : "rgba(255,255,255,.35)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(point.x, point.y, worldRadius(tower.range), 0, Math.PI * 2);
  ctx.stroke();
}

function drawPhaseOverlay() {
  if (state.phase === "playing") return;
  ctx.fillStyle = "rgba(0,0,0,.45)";
  ctx.fillRect(0, 0, mapWidth(), mapHeight());
  ctx.fillStyle = "#fff0a8";
  ctx.font = "bold 40px sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(state.phase === "lobby" ? "等待玩家准备" : "游戏结束", mapWidth() / 2, mapHeight() / 2);
  ctx.textAlign = "left";
}

function isPathCell(gridX, gridY) {
  return config.mainPathCells.some((cell) => cell[0] === gridX && cell[1] === gridY);
}

function getBuildSlotAt(gridX, gridY) {
  const entry = Object.entries(config.buildAreas).find(([, areas]) => (
    areas.some((area) => gridX >= area.minX && gridX <= area.maxX && gridY >= area.minY && gridY <= area.maxY)
  ));
  return entry ? Number(entry[0]) : null;
}

function getUpgradeCost(tower) {
  return Math.round(config.towerTypes[tower.typeKey].cost * (0.75 + tower.level * 0.58));
}

function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

joinBtn.addEventListener("click", () => send("join", { name: nameInput.value, slot: Number(slotSelect.value) }));
readyBtn.addEventListener("click", () => send("ready", { ready: !(state.players[mySlot]?.ready) }));
startWaveBtn.addEventListener("click", () => send("startWave"));
speedBtn.addEventListener("click", () => send("speed", { speed: state.speed >= 3 ? 1 : state.speed + 1 }));
resetBtn.addEventListener("click", () => send("reset"));
upgradeBtn.addEventListener("click", () => selectedTowerId && send("upgrade", { towerId: selectedTowerId }));
sellBtn.addEventListener("click", () => {
  if (!selectedTowerId) return;
  send("sell", { towerId: selectedTowerId });
  selectedTowerId = null;
});
canvas.addEventListener("click", handleCanvasClick);
canvas.addEventListener("mousemove", (event) => { mouse = canvasPoint(event); });
canvas.addEventListener("mouseleave", () => { mouse = null; });
document.addEventListener("keydown", (event) => {
  const keyMap = {
    Digit1: "arrow",
    Digit2: "frost",
    Digit3: "cannon",
    Digit4: "poison",
    KeyQ: "arrow",
    KeyW: "frost",
    KeyE: "cannon",
    KeyR: "poison",
    KeyY: "armorbreak",
    KeyU: "corrosion",
    KeyT: "aura_speed",
    KeyG: "aura_damage",
    KeyI: "growth_kill",
    KeyK: "growth_gold",
  };
  const typeKey = keyMap[event.code];
  if (!typeKey || !config) return;
  selectedTowerType = typeKey;
  selectedTowerId = null;
  renderTowerButtons();
  updateSelectionPanel();
});
