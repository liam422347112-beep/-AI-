const http = require("http");
const os = require("os");
const path = require("path");
const fs = require("fs");
const { WebSocketServer } = require("ws");

const port = Number(process.env.PORT || 5252);
const publicDir = path.join(__dirname, "public");
const tickRate = 30;
const gridSize = 38;
const cols = 30;
const rows = 20;
const totalWaves = 35;

const towerTypes = {
  arrow: { name: "箭塔", cost: 50, damage: 20, range: 133, rate: 0.58, color: "#d8f6ff", desc: "高速单体", damageType: "physical", category: "basic" },
  frost: { name: "冰塔", cost: 70, damage: 9, range: 124, rate: 0.9, color: "#85d7ff", slow: 0.45, slowTime: 1.35, desc: "减速控制", damageType: "magic", category: "basic" },
  cannon: { name: "炮塔", cost: 100, damage: 35, range: 119, rate: 1.15, color: "#ffb347", splash: 64, desc: "范围伤害", damageType: "pierce", category: "basic" },
  poison: { name: "毒塔", cost: 80, damage: 11, range: 128, rate: 0.82, color: "#a6ff4d", poison: 11, poisonTime: 2.8, desc: "持续伤害", damageType: "chaos", category: "basic" },
  armorbreak: { name: "减防塔", cost: 120, damage: 8, range: 131, rate: 1.0, color: "#ff6b6b", desc: "降低目标护甲", damageType: "physical", category: "debuff" },
  corrosion: { name: "腐蚀塔", cost: 90, damage: 12, range: 125, rate: 0.85, color: "#b8ff3b", desc: "减防debuff 3秒", damageType: "chaos", category: "debuff" },
  aura_speed: { name: "攻速光环", cost: 150, damage: 0, range: 190, rate: 9999, color: "#ffe680", desc: "友方+20%攻速", damageType: "magic", isAura: true, auraType: "speed", category: "aura" },
  aura_damage: { name: "伤害光环", cost: 170, damage: 0, range: 175, rate: 9999, color: "#ffb0e0", desc: "友方+15%伤害", damageType: "magic", isAura: true, auraType: "damage", category: "aura" },
  growth_kill: { name: "杀戮成长", cost: 200, damage: 25, range: 143, rate: 0.7, color: "#3bff88", desc: "击杀+2永久伤害", damageType: "pierce", growthType: "damage", category: "growth" },
  growth_gold: { name: "吸金成长", cost: 180, damage: 18, range: 133, rate: 0.65, color: "#ffd700", desc: "击杀+3金币", damageType: "physical", growthType: "gold", category: "growth" },
};

// 伤害/护甲克制系统
// 物理克魔法护甲，魔法克物理护甲，穿刺克抗性护甲，混乱克神圣护甲
const damageTypes = { physical: "物理", magic: "魔法", pierce: "穿刺", chaos: "混乱" };
const armorTypes = { physical: "物理", magic: "魔法", resistance: "抗性", holy: "神圣" };
const counterMap = {
  physical: "magic",    // 物理克魔法护甲
  magic: "physical",    // 魔法克物理护甲
  pierce: "resistance", // 穿刺克抗性护甲
  chaos: "holy",        // 混乱克神圣护甲
};
const weakAgainst = {
  physical: "holy",       // 物理被神圣护甲克制
  magic: "magic",         // 魔法被魔法护甲克制
  pierce: "physical",     // 穿刺被物理护甲克制
  chaos: "resistance",    // 混乱被抗性护甲克制
};
function getDamageMultiplier(damageType, armorType) {
  if (counterMap[damageType] === armorType) return 2.0;   // 克制：2倍伤害
  if (weakAgainst[damageType] === armorType) return 0.3;  // 被克：0.3倍
  return 1.0;                                              // 普通：1倍
}

// 经典绿色循环圈：三圈同心圆环螺旋路线（联机版 30x20）
// 外圈顺时针 → 中圈逆时针 → 内圈顺时针 → 中心出口
function range(start, end) {
  const step = start <= end ? 1 : -1;
  const cells = [];
  for (let value = start; value !== end + step; value += step) cells.push(value);
  return cells;
}

// 标准地图布局：30x20，参考 地图.png 的四入口、双四边形圈、中心 2x2 终点结构。
function hLine(x1, x2, y) { return range(x1, x2).map(x => [x, y]); }
function vLine(y1, y2, x) { return range(y1, y2).map(y => [x, y]); }

const path1 = [
  [0, 2], [1, 2],
  ...hLine(2, 27, 2), ...vLine(3, 17, 27), ...hLine(26, 2, 17), ...vLine(16, 2, 2), ...hLine(3, 14, 2),
  ...vLine(3, 5, 14),
  ...hLine(15, 23, 5), ...vLine(6, 14, 23), ...hLine(22, 6, 14), ...vLine(13, 5, 6), ...hLine(7, 11, 5),
  ...vLine(6, 9, 11), ...hLine(12, 14, 9),
];

const path2 = [
  [27, 0], [27, 1],
  ...vLine(2, 17, 27), ...hLine(26, 2, 17), ...vLine(16, 2, 2), ...hLine(3, 27, 2), ...vLine(3, 9, 27),
  ...hLine(26, 23, 9),
  ...vLine(10, 14, 23), ...hLine(22, 6, 14), ...vLine(13, 5, 6), ...hLine(7, 23, 5), ...vLine(6, 8, 23),
  ...hLine(22, 15, 8), [15, 9],
];

const path3 = [
  [29, 17], [28, 17],
  ...hLine(27, 2, 17), ...vLine(16, 2, 2), ...hLine(3, 27, 2), ...vLine(3, 17, 27), ...hLine(26, 15, 17),
  ...vLine(16, 14, 15),
  ...hLine(16, 6, 14), ...vLine(13, 5, 6), ...hLine(7, 23, 5), ...vLine(6, 14, 23), ...hLine(22, 19, 14),
  ...vLine(13, 10, 19), ...hLine(18, 15, 10),
];

const path4 = [
  [2, 19], [2, 18],
  ...vLine(17, 2, 2), ...hLine(3, 27, 2), ...vLine(3, 17, 27), ...hLine(26, 2, 17), ...vLine(16, 10, 2),
  ...hLine(3, 6, 10),
  ...vLine(9, 5, 6), ...hLine(7, 23, 5), ...vLine(6, 14, 23), ...hLine(22, 6, 14), ...vLine(13, 12, 6),
  ...hLine(7, 14, 12), ...vLine(11, 10, 14),
];

const pathRoutes = { 1: path1, 2: path2, 3: path3, 4: path4 };
const mainPathCells = [...new Map(Object.values(pathRoutes).flat().map(cell => [`${cell[0]},${cell[1]}`, cell])).values()];
const mainPathSet = new Set(mainPathCells.map(([x, y]) => `${x},${y}`));

const playerRoles = {
  1: { name: "左上外圈", ring: "outer", color: "#6ee76a" },
  2: { name: "右上外圈", ring: "outer", color: "#6ab2ff" },
  3: { name: "右下外圈", ring: "outer", color: "#ffcf5a" },
  4: { name: "左下外圈", ring: "outer", color: "#ff7fd1" },
  5: { name: "左上内圈", ring: "inner", color: "#ff9b6a" },
  6: { name: "右上内圈", ring: "inner", color: "#b98cff" },
  7: { name: "右下内圈", ring: "inner", color: "#73e6ff" },
  8: { name: "左下内圈", ring: "inner", color: "#c7ff5a" },
};
const buildAreas = {
  1: [{ minX: 0, maxX: 13, minY: 0, maxY: 4 }],
  2: [{ minX: 16, maxX: 29, minY: 0, maxY: 4 }],
  3: [{ minX: 16, maxX: 29, minY: 15, maxY: 19 }],
  4: [{ minX: 0, maxX: 13, minY: 15, maxY: 19 }],
  5: [{ minX: 7, maxX: 13, minY: 6, maxY: 8 }],
  6: [{ minX: 16, maxX: 22, minY: 6, maxY: 8 }],
  7: [{ minX: 16, maxX: 22, minY: 11, maxY: 13 }],
  8: [{ minX: 7, maxX: 13, minY: 11, maxY: 13 }],
};

let game = createGame();

function createGame() {
  return {
    phase: "lobby",
    hostSlot: null,
    wave: 0,
    spawning: false,
    spawnTimer: 0,
    spawnCount: 0,
    speed: 1,
    players: {},
    towers: [],
    enemies: [],
    projectiles: [],
    effects: [],
    nextTowerId: 1,
    nextEnemyId: 1,
    nextProjectileId: 1,
    logs: [],
  };
}

function createPlayer(clientId, slot, name) {
  return {
    clientId,
    slot,
    name: name.slice(0, 12) || `玩家${slot}`,
    lives: 20,
    gold: 220,
    ready: false,
    connected: true,
  };
}

const server = http.createServer((req, res) => {
  const urlPath = decodeURIComponent(req.url.split("?")[0]);
  const filePath = path.join(publicDir, urlPath === "/" ? "index.html" : urlPath);
  if (!filePath.startsWith(publicDir)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }
  fs.readFile(filePath, (error, data) => {
    if (error) {
      res.writeHead(404);
      res.end("Not found");
      return;
    }
    res.writeHead(200, { "Content-Type": contentType(filePath) });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server });
const clients = new Map();
let nextClientId = 1;

wss.on("connection", (ws) => {
  const clientId = nextClientId++;
  clients.set(clientId, { ws, slot: null });
  send(ws, "hello", { clientId, towerTypes, playerRoles, buildAreas, pathRoutes, mainPathCells, gridSize, cols, rows, totalWaves });
  broadcastState();

  ws.on("message", (raw) => {
    let message;
    try {
      message = JSON.parse(raw.toString());
    } catch {
      return;
    }
    handleMessage(clientId, message);
  });

  ws.on("close", () => {
    const client = clients.get(clientId);
    if (client?.slot && game.players[client.slot]) {
      game.players[client.slot].connected = false;
      addLog(`${game.players[client.slot].name} 断开连接。`);
      updateHostSlot();
    }
    clients.delete(clientId);
    broadcastState();
  });
});

function handleMessage(clientId, message) {
  const client = clients.get(clientId);
  if (!client) return;

  if (message.type === "join") joinSlot(clientId, message);
  if (message.type === "ready") setReady(clientId, message.ready);
  if (message.type === "startWave") startWave(clientId);
  if (message.type === "build") buildTower(clientId, message);
  if (message.type === "upgrade") upgradeTower(clientId, message.towerId);
  if (message.type === "sell") sellTower(clientId, message.towerId);
  if (message.type === "speed") setSpeed(clientId, message.speed);
  if (message.type === "reset") resetGame(clientId);
}

function joinSlot(clientId, message) {
  if (game.phase !== "lobby") {
    send(clients.get(clientId).ws, "error", { message: "游戏已经开始，只能观战。" });
    return;
  }
  const slot = Number(message.slot);
  if (!playerRoles[slot]) return;
  const existing = game.players[slot];
  if (existing?.connected && existing.clientId !== clientId) {
    send(clients.get(clientId).ws, "error", { message: "该位置已经有人。" });
    return;
  }
  const client = clients.get(clientId);
  if (client.slot && game.players[client.slot]?.clientId === clientId) delete game.players[client.slot];
  client.slot = slot;
  game.players[slot] = createPlayer(clientId, slot, String(message.name || ""));
  updateHostSlot();
  addLog(`${game.players[slot].name} 加入 ${slot} 号位。`);
  broadcastState();
}

function setReady(clientId, ready) {
  const player = getPlayerByClient(clientId);
  if (!player || game.phase !== "lobby") return;
  player.ready = Boolean(ready);
  addLog(`${player.name}${player.ready ? "已准备" : "取消准备"}。`);
  broadcastState();
}

function startWave(clientId) {
  if (!isHostClient(clientId)) return;
  if (game.phase === "ended") return;
  if (game.phase === "lobby") {
    const active = activePlayers();
    if (active.length === 0 || active.some((player) => !player.ready)) return;
    game.phase = "playing";
  }
  if (game.spawning || game.enemies.length > 0 || game.wave >= totalWaves) return;
  game.wave += 1;
  game.spawning = true;
  game.spawnTimer = 0;
  game.spawnCount = 0;
  const config = getWaveConfig(game.wave);
  addLog(`第 ${game.wave} 波：${config.name} x ${config.count}。`);
  broadcastState();
}

function buildTower(clientId, message) {
  const player = getPlayerByClient(clientId);
  if (!player || game.phase === "ended") return;
  const type = towerTypes[message.towerType];
  const gridX = Number(message.gridX);
  const gridY = Number(message.gridY);
  if (!type || !canBuildAt(player.slot, gridX, gridY)) return;
  if (player.gold < type.cost) return;
  player.gold -= type.cost;
  game.towers.push({
    id: game.nextTowerId++,
    ownerSlot: player.slot,
    gridX,
    gridY,
    x: gridX * gridSize + gridSize / 2,
    y: gridY * gridSize + gridSize / 2,
    typeKey: message.towerType,
    level: 1,
    damage: type.damage,
    range: type.range,
    rate: type.rate,
    cooldown: 0,
    spent: type.cost,
  });
  addLog(`${player.name} 建造${type.name}。`);
  broadcastState();
}

function upgradeTower(clientId, towerId) {
  const player = getPlayerByClient(clientId);
  const tower = game.towers.find((item) => item.id === towerId && item.ownerSlot === player?.slot);
  if (!player || !tower || tower.level >= 5) return;
  const cost = getUpgradeCost(tower);
  if (player.gold < cost) return;
  player.gold -= cost;
  tower.spent += cost;
  tower.level += 1;
  tower.damage *= 1.42;
  tower.range += 10;
  tower.rate = Math.max(0.28, tower.rate * 0.9);
  addLog(`${player.name} 升级${towerTypes[tower.typeKey].name}到 Lv.${tower.level}。`);
  broadcastState();
}

function sellTower(clientId, towerId) {
  const player = getPlayerByClient(clientId);
  const index = game.towers.findIndex((item) => item.id === towerId && item.ownerSlot === player?.slot);
  if (!player || index === -1) return;
  const tower = game.towers[index];
  const refund = Math.floor(tower.spent * 0.65);
  player.gold += refund;
  game.towers.splice(index, 1);
  addLog(`${player.name} 出售${towerTypes[tower.typeKey].name}。`);
  broadcastState();
}

function updateHostSlot() {
  const previous = game.hostSlot;
  const onlineSlots = Object.values(game.players)
    .filter((player) => player.connected)
    .map((player) => player.slot)
    .sort((a, b) => a - b);
  game.hostSlot = onlineSlots[0] || null;
  if (game.hostSlot && previous && previous !== game.hostSlot) {
    const host = game.players[game.hostSlot];
    addLog(`房主已转移给 ${game.hostSlot}号 ${host.name}。`);
  }
}

function isHostClient(clientId) {
  return game.hostSlot && game.players[game.hostSlot]?.clientId === clientId && game.players[game.hostSlot]?.connected;
}

function setSpeed(clientId, speed) {
  if (!isHostClient(clientId)) return;
  if (![1, 2, 3].includes(Number(speed))) return;
  game.speed = Number(speed);
  broadcastState();
}

function resetGame(clientId) {
  const client = clients.get(clientId);
  const canReset = isHostClient(clientId) || game.phase === "ended";
  if (!canReset) return;
  const oldPlayers = Object.values(game.players).filter((player) => player.connected);
  game = createGame();
  oldPlayers.forEach((player) => {
    const existingClient = clients.get(player.clientId);
    if (!existingClient) return;
    existingClient.slot = player.slot;
    game.players[player.slot] = createPlayer(player.clientId, player.slot, player.name);
  });
  if (client && !client.slot) client.slot = null;
  updateHostSlot();
  addLog("游戏已重置。所有玩家请重新准备。");
  broadcastState();
}

function canBuildAt(slot, gridX, gridY) {
  const areas = buildAreas[slot];
  if (!areas) return false;
  return Number.isInteger(gridX)
    && Number.isInteger(gridY)
    && areas.some((area) => gridX >= area.minX && gridX <= area.maxX && gridY >= area.minY && gridY <= area.maxY)
    && !mainPathSet.has(`${gridX},${gridY}`)
    && !game.towers.some((tower) => tower.gridX === gridX && tower.gridY === gridY);
}

function update(dt) {
  if (game.phase !== "playing") return;
  updateSpawning(dt);
  updateEnemies(dt);
  updateTowers(dt);
  updateProjectiles(dt);
  updateEffects(dt);
  if (game.wave >= totalWaves && !game.spawning && game.enemies.length === 0) {
    game.phase = "ended";
    addLog("防守成功，全部波次已完成。");
  }
}

function updateSpawning(dt) {
  if (!game.spawning) return;
  const config = getWaveConfig(game.wave);
  game.spawnTimer -= dt;
  if (game.spawnTimer <= 0 && game.spawnCount < config.count) {
    spawnEnemy(config);
    game.spawnCount += 1;
    game.spawnTimer = config.interval;
  }
  if (game.spawnCount >= config.count) game.spawning = false;
}

function spawnEnemy(config) {
  Object.entries(pathRoutes).forEach(([slot, route]) => {
    const [x, y] = route[0];
    game.enemies.push({
      id: game.nextEnemyId++,
      route,
      name: config.name,
      x: x * gridSize + gridSize / 2,
      y: y * gridSize + gridSize / 2,
      pathIndex: 0,
      hp: Math.round(config.hp * 0.78),
      maxHp: Math.round(config.hp * 0.78),
      baseSpeed: config.speed,
      reward: Math.max(2, Math.round(config.reward * 0.45)),
      armor: config.armor,
      armorType: config.armorType,
      color: config.color,
      slowTimer: 0,
      slowFactor: 1,
      poisonTimer: 0,
      poisonDamage: 0,
      lastHitSlot: Number(slot),
    });
  });
}

function updateEnemies(dt) {
  for (let i = game.enemies.length - 1; i >= 0; i -= 1) {
    const enemy = game.enemies[i];
    if (enemy.slowTimer > 0) enemy.slowTimer -= dt;
    else enemy.slowFactor = 1;
    if (enemy.poisonTimer > 0) {
      enemy.poisonTimer -= dt;
      enemy.hp -= enemy.poisonDamage * dt;
    }
    // 腐蚀塔debuff：持续降低护甲
    if (enemy.armorDebuffTimer > 0) {
      enemy.armorDebuffTimer -= dt;
      enemy.armor = Math.max(0.3, (enemy.armor || 1) - (enemy.armorDebuff || 0) * dt);
    }
    if (enemy.hp <= 0) {
      const player = game.players[enemy.lastHitSlot];
      if (player) player.gold += enemy.reward;
      // 成长塔效果
      game.towers.forEach((tower) => {
        if (tower.ownerSlot !== enemy.lastHitSlot) return;
        const type = towerTypes[tower.typeKey];
        if (type.growthType === "damage") tower.damage += 2;
        if (type.growthType === "gold" && player) player.gold += 3;
      });
      game.effects.push({ x: enemy.x, y: enemy.y, radius: 21, life: 0.25, color: "rgba(255,226,102,.5)" });
      game.enemies.splice(i, 1);
      continue;
    }
    moveEnemy(enemy, dt);
    const route = enemy.route || mainPathCells;
    if (enemy.pathIndex >= route.length - 1) {
      game.enemies.splice(i, 1);
      const damage = enemy.name === "Boss" ? 5 : 1;
      activePlayers().forEach((player) => {
        player.lives = Math.max(0, player.lives - damage);
      });
      if (activePlayers().some((player) => player.lives <= 0)) {
        game.phase = "ended";
        addLog("怪物突破大环，全队失败。");
      }
    }
  }
}

function moveEnemy(enemy, dt) {
  const route = enemy.route || mainPathCells;
  const targetCell = route[enemy.pathIndex + 1];
  if (!targetCell) return;
  const target = { x: targetCell[0] * gridSize + gridSize / 2, y: targetCell[1] * gridSize + gridSize / 2 };
  const dx = target.x - enemy.x;
  const dy = target.y - enemy.y;
  const length = Math.hypot(dx, dy);
  const step = enemy.baseSpeed * enemy.slowFactor * dt;
  if (step >= length) {
    enemy.x = target.x;
    enemy.y = target.y;
    enemy.pathIndex += 1;
    return;
  }
  enemy.x += (dx / length) * step;
  enemy.y += (dy / length) * step;
}

function updateTowers(dt) {
  // 第一步：重置所有buff，再统一应用光环
  game.towers.forEach((tower) => { tower.auraSpeedBuff = 1; tower.auraDamageBuff = 0; });
  game.towers.forEach((tower) => {
    const type = towerTypes[tower.typeKey];
    if (!type.isAura) return;
    game.towers.forEach((ally) => {
      if (ally.id === tower.id) return;
      if (distance(tower, ally) <= tower.range) {
        if (type.auraType === "speed") ally.auraSpeedBuff = Math.min(ally.auraSpeedBuff, 0.8);
        if (type.auraType === "damage") ally.auraDamageBuff = Math.max(ally.auraDamageBuff, 0.15);
      }
    });
  });
  // 第二步：攻击塔使用buff
  game.towers.forEach((tower) => {
    if (towerTypes[tower.typeKey].isAura) return;
    tower.cooldown -= dt;
    if (tower.cooldown > 0) return;
    const target = findTarget(tower);
    if (!target) return;
    tower.cooldown = tower.rate * tower.auraSpeedBuff;
    game.projectiles.push({ id: game.nextProjectileId++, x: tower.x, y: tower.y, targetId: target.id, towerId: tower.id, speed: towerTypes[tower.typeKey].splash ? 460 : 620, color: towerTypes[tower.typeKey].color, damageBonus: tower.auraDamageBuff });
  });
}

function findTarget(tower) {
  let best = null;
  let bestProgress = -1;
  game.enemies.forEach((enemy) => {
    if (distance(tower, enemy) > tower.range) return;
    const progress = enemy.pathIndex * 10000 + enemy.x + enemy.y;
    if (progress > bestProgress) {
      best = enemy;
      bestProgress = progress;
    }
  });
  return best;
}

function updateProjectiles(dt) {
  for (let i = game.projectiles.length - 1; i >= 0; i -= 1) {
    const projectile = game.projectiles[i];
    const tower = game.towers.find((item) => item.id === projectile.towerId);
    const target = game.enemies.find((enemy) => enemy.id === projectile.targetId);
    if (!tower || !target) {
      game.projectiles.splice(i, 1);
      continue;
    }
    const dx = target.x - projectile.x;
    const dy = target.y - projectile.y;
    const length = Math.hypot(dx, dy);
    const step = projectile.speed * dt;
    if (step >= length) {
      hitEnemy(tower, target, projectile.damageBonus || 0);
      game.projectiles.splice(i, 1);
      continue;
    }
    projectile.x += (dx / length) * step;
    projectile.y += (dy / length) * step;
  }
}

function hitEnemy(tower, target, damageBonus) {
  const type = towerTypes[tower.typeKey];
  const multiplier = getDamageMultiplier(type.damageType, target.armorType || "physical");
  const dmgBonus = 1 + (damageBonus || 0);
  const finalDamage = tower.damage * target.armor * multiplier * dmgBonus;
  if (type.splash) {
    game.enemies.forEach((enemy) => {
      if (distance(target, enemy) <= type.splash + tower.level * 5) {
        const m = getDamageMultiplier(type.damageType, enemy.armorType || "physical");
        enemy.hp -= tower.damage * enemy.armor * m * dmgBonus;
        enemy.lastHitSlot = tower.ownerSlot;
      }
    });
    game.effects.push({ x: target.x, y: target.y, radius: type.splash + tower.level * 6, life: 0.2, color: "rgba(255,155,64,.35)" });
    return;
  }
  target.hp -= finalDamage;
  target.lastHitSlot = tower.ownerSlot;
  if (type.slow) {
    target.slowFactor = type.slow;
    target.slowTimer = type.slowTime + tower.level * 0.12;
  }
  if (type.poison) {
    target.poisonDamage = type.poison + tower.level * 4;
    target.poisonTimer = type.poisonTime;
  }
  if (tower.typeKey === "armorbreak") {
    target.armor = Math.max(0.3, (target.armor || 1) - 0.15);
  }
  if (tower.typeKey === "corrosion") {
    target.armorDebuff = 0.2;
    target.armorDebuffTimer = 3.0;
  }
  game.effects.push({ x: target.x, y: target.y, radius: 14, life: 0.16, color: "rgba(210,255,169,.35)" });
}

function updateEffects(dt) {
  for (let i = game.effects.length - 1; i >= 0; i -= 1) {
    game.effects[i].life -= dt;
    if (game.effects[i].life <= 0) game.effects.splice(i, 1);
  }
}

function getWaveConfig(waveNumber) {
  const boss = waveNumber % 5 === 0;
  const airship = waveNumber % 7 === 0 && !boss;
  const tank = waveNumber % 6 === 0 && !boss && !airship;
  const fast = waveNumber % 4 === 0 && !boss && !airship && !tank;
  const heavy = waveNumber % 3 === 0 && !boss && !airship && !tank;
  // 每波指定护甲类型，循环：物理→魔法→抗性→神圣
  const armorCycle = ["physical", "magic", "resistance", "holy"];
  const armorType = boss ? "holy" : armorCycle[(waveNumber - 1) % 4];
  const baseHp = Math.round((boss ? 390 : tank ? 174 : heavy ? 95 : 58) * Math.pow(1.15, waveNumber - 1));
  return {
    name: boss ? "Boss" : airship ? "飞艇" : tank ? "战车" : fast ? "迅捷怪" : heavy ? "重甲怪" : "普通怪",
    count: boss ? 1 + Math.floor(waveNumber / 10) : 10 + waveNumber * 3,
    hp: airship ? Math.round(baseHp * 0.6) : baseHp,
    speed: boss ? 34 : airship ? 90 : tank ? 30 : fast ? 78 : heavy ? 38 : 52,
    reward: boss ? 85 + waveNumber * 8 : airship ? 12 + Math.floor(waveNumber * 2) : tank ? 18 + Math.floor(waveNumber * 2.5) : 8 + Math.floor(waveNumber * 1.5),
    armor: tank ? 0.5 : heavy ? 0.82 : 1,
    armorType,
    armorTypeName: armorTypes[armorType],
    interval: boss ? 1.2 : airship ? 0.4 : tank ? 0.9 : 0.55,
    color: boss ? "#b14cff" : airship ? "#73e6ff" : tank ? "#ff9b6a" : fast ? "#ffe266" : heavy ? "#c66f45" : "#ff5656",
  };
}

function getUpgradeCost(tower) {
  return Math.round(towerTypes[tower.typeKey].cost * (0.75 + tower.level * 0.58));
}

function activePlayers() {
  return Object.values(game.players).filter((player) => player.connected);
}

function getPlayerByClient(clientId) {
  return Object.values(game.players).find((player) => player.clientId === clientId && player.connected);
}

function addLog(message) {
  game.logs.unshift({ time: Date.now(), message });
  game.logs = game.logs.slice(0, 12);
}

function snapshotFor(clientId) {
  // 统计每个玩家的塔数量
  const towerCounts = {};
  game.towers.forEach(t => { towerCounts[t.ownerSlot] = (towerCounts[t.ownerSlot] || 0) + 1; });
  return {
    clientId,
    phase: game.phase,
    hostSlot: game.hostSlot,
    wave: game.wave,
    totalWaves,
    spawning: game.spawning,
    spawnCount: game.spawnCount,
    waveConfig: game.wave > 0 ? getWaveConfig(game.wave) : null,
    nextWaveConfig: game.wave < totalWaves ? getWaveConfig(game.wave + 1) : null,
    speed: game.speed,
    players: game.players,
    towers: game.towers,
    towerCounts,
    enemies: game.enemies,
    projectiles: game.projectiles,
    effects: game.effects,
    logs: game.logs,
  };
}

function broadcastState() {
  clients.forEach((client, clientId) => send(client.ws, "state", snapshotFor(clientId)));
}

function send(ws, type, payload) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify({ type, ...payload }));
}

function distance(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function contentType(filePath) {
  if (filePath.endsWith(".html")) return "text/html; charset=utf-8";
  if (filePath.endsWith(".css")) return "text/css; charset=utf-8";
  if (filePath.endsWith(".js")) return "application/javascript; charset=utf-8";
  return "application/octet-stream";
}

function getLanAddresses() {
  return Object.values(os.networkInterfaces())
    .flat()
    .filter((item) => item && item.family === "IPv4" && !item.internal)
    .map((item) => `http://${item.address}:${port}`);
}

setInterval(() => {
  update((1 / tickRate) * game.speed);
  broadcastState();
}, 1000 / tickRate);

server.listen(port, "0.0.0.0", () => {
  console.log(`本机访问：http://localhost:${port}`);
  getLanAddresses().forEach((address) => console.log(`局域网访问：${address}`));
});
